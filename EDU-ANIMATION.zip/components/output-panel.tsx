"use client"

import { useState, useEffect } from "react"
import { Card } from "@/components/ui/card"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { useAnimationContext } from "@/hooks/use-animation-context"
import type { GenerateResponse } from "@/lib/types"
import { parseSentencesWithTimestamps } from "@/lib/subtitle-generator"

interface OutputPanelProps {
  animationData: GenerateResponse | null
  voiceScript: string
  subtitles: string
  duration: number
  audioUrl: string | null
}

export default function OutputPanel({ animationData, voiceScript, subtitles, duration, audioUrl }: OutputPanelProps) {
  const { currentTime } = useAnimationContext()
  const [sentences, setSentences] = useState<Array<{ text: string; startTime: number; endTime: number }>>([])

  // Parse sentences with timestamps
  useEffect(() => {
    if (voiceScript && duration) {
      const parsed = parseSentencesWithTimestamps(voiceScript, duration)
      setSentences(parsed)
    }
  }, [voiceScript, duration])

  const getCurrentSentenceIndex = () => {
    return sentences.findIndex((s) => currentTime >= s.startTime && currentTime < s.endTime)
  }

  const currentIndex = getCurrentSentenceIndex()

  return (
    <div className="p-4 space-y-4 h-full overflow-y-auto">
      <h2 className="text-xl font-bold">Outputs</h2>

      {/* Scene Breakdown */}
      {animationData?.scenes && (
        <Card className="p-3">
          <Accordion type="single" collapsible defaultValue="scene-0">
            {animationData.scenes.map((scene, idx) => (
              <AccordionItem key={scene.id} value={`scene-${idx}`}>
                <AccordionTrigger className="text-xs font-medium py-2">{scene.name}</AccordionTrigger>
                <AccordionContent className="text-xs space-y-1 pt-2">
                  <p>
                    <strong>Type:</strong> {scene.animationType}
                  </p>
                  <p>
                    <strong>Duration:</strong> {scene.duration}s
                  </p>
                  <p className="text-muted-foreground">{scene.description}</p>
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </Card>
      )}

      {/* Instructions JSON */}
      {animationData?.instructions && (
        <Card className="p-3">
          <details className="cursor-pointer group">
            <summary className="font-medium text-xs mb-2 group-open:mb-2">Instruction JSON</summary>
            <pre className="text-xs overflow-auto max-h-32 bg-muted p-2 rounded text-foreground/80 font-mono">
              {JSON.stringify(animationData.instructions, null, 2)}
            </pre>
          </details>
        </Card>
      )}

      {/* Text Explanation with Auto-Highlight */}
      {voiceScript && (
        <Card className="p-3 space-y-2">
          <h3 className="font-medium text-xs">Text (Auto-Highlighting)</h3>
          <div className="max-h-48 overflow-y-auto space-y-1">
            {sentences.length > 0 ? (
              sentences.map((sentence, idx) => {
                const isActive = idx === currentIndex
                return (
                  <div
                    key={idx}
                    className={`p-2 rounded text-xs cursor-pointer transition-all duration-200 ${
                      isActive
                        ? "bg-primary text-primary-foreground font-medium scale-105"
                        : "bg-muted text-muted-foreground hover:bg-muted/80"
                    }`}
                    onClick={() => {
                      // Allow seeking by clicking sentences (requires audio element access)
                      window.dispatchEvent(
                        new CustomEvent("seekToTime", {
                          detail: sentence.startTime,
                        }),
                      )
                    }}
                  >
                    {sentence.text}
                  </div>
                )
              })
            ) : (
              <p className="text-xs text-muted-foreground italic">Loading...</p>
            )}
          </div>
        </Card>
      )}

      {/* Subtitles Info */}
      {subtitles && (
        <Card className="p-3">
          <p className="text-xs text-muted-foreground">
            ✓ Subtitles generated ({subtitles.split("\n\n").length} entries)
          </p>
        </Card>
      )}
    </div>
  )
}
