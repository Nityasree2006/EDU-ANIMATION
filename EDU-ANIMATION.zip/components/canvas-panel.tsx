"use client"

import { useRef, useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import {
  renderBernoulliAnimation,
  renderMatrixExpmAnimation,
  renderSineWaveAnimation,
  renderBubbleSortAnimation,
  renderVectorAdditionAnimation,
  renderRotatingTriangleAnimation,
} from "@/lib/animation-renderer"
import type { GenerateResponse } from "@/lib/types"

interface CanvasPanelProps {
  animationData: GenerateResponse | null
  audioUrl: string | null
  duration: number
  subtitles: string
  voiceScript: string
}

export default function CanvasPanel({ animationData, audioUrl, duration, subtitles, voiceScript }: CanvasPanelProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const audioRef = useRef<HTMLAudioElement>(null)
  const mediaRecorderRef = useRef<MediaRecorder | null>(null)
  const recordedChunksRef = useRef<Blob[]>([])
  const synthRef = useRef<SpeechSynthesisUtterance | null>(null)
  const startTimeRef = useRef<number>(0)

  const [isPlaying, setIsPlaying] = useState(false)
  const [currentTime, setCurrentTime] = useState(0)
  const [isRecording, setIsRecording] = useState(false)
  const [useWebSpeech, setUseWebSpeech] = useState(!audioUrl)
  const animationFrameRef = useRef<number>()

  useEffect(() => {
    if (!animationData || !canvasRef.current) return

    const canvas = canvasRef.current
    const ctx = canvas.getContext("2d")
    if (!ctx) return

    const render = () => {
      // Use audio time if playing with audio, otherwise use manual/Web Speech time
      let time = currentTime

      if (audioRef.current && isPlaying && !useWebSpeech) {
        time = audioRef.current.currentTime
      }

      // Clamp time to duration
      time = Math.min(time, duration)
      setCurrentTime(time)

      const animationType = animationData.scenes?.[0]?.animationType
      const scene = animationData.scenes?.[0]

      if (animationType && scene) {
        switch (animationType) {
          case "bernoulli":
            renderBernoulliAnimation({ ctx, canvas, time, duration, width: canvas.width, height: canvas.height }, scene)
            break
          case "matrix-expm":
            renderMatrixExpmAnimation(
              { ctx, canvas, time, duration, width: canvas.width, height: canvas.height },
              scene,
            )
            break
          case "sine-wave":
            renderSineWaveAnimation({
              ctx,
              canvas,
              time,
              duration,
              width: canvas.width,
              height: canvas.height,
            })
            break
          case "bubble-sort":
            renderBubbleSortAnimation({
              ctx,
              canvas,
              time,
              duration,
              width: canvas.width,
              height: canvas.height,
            })
            break
          case "vector-addition":
            renderVectorAdditionAnimation({
              ctx,
              canvas,
              time,
              duration,
              width: canvas.width,
              height: canvas.height,
            })
            break
          case "rotating-triangle":
            renderRotatingTriangleAnimation({
              ctx,
              canvas,
              time,
              duration,
              width: canvas.width,
              height: canvas.height,
            })
            break
        }
      }

      // Broadcast time update for other components
      window.dispatchEvent(new CustomEvent("audioTimeUpdate", { detail: time }))

      if (isPlaying) {
        animationFrameRef.current = requestAnimationFrame(render)
      }
    }

    if (isPlaying) {
      animationFrameRef.current = requestAnimationFrame(render)
    } else if (currentTime > 0) {
      render() // Render once when paused
    }

    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current)
      }
    }
  }, [animationData, isPlaying, currentTime, duration, useWebSpeech])

  useEffect(() => {
    const audio = audioRef.current
    if (!audio) return

    const updateTime = () => {
      setCurrentTime(audio.currentTime)
      window.dispatchEvent(new CustomEvent("audioTimeUpdate", { detail: audio.currentTime }))
    }

    const handleEnded = () => {
      setIsPlaying(false)
    }

    audio.addEventListener("timeupdate", updateTime)
    audio.addEventListener("ended", handleEnded)

    return () => {
      audio.removeEventListener("timeupdate", updateTime)
      audio.removeEventListener("ended", handleEnded)
    }
  }, [])

  useEffect(() => {
    if (!isPlaying || !useWebSpeech) return

    if (!voiceScript) return

    const synth = window.speechSynthesis

    if (synth.speaking) {
      synth.cancel()
    }

    const utterance = new SpeechSynthesisUtterance(voiceScript)
    utterance.rate = 1
    utterance.pitch = 1
    utterance.volume = 1

    let startTime = 0

    utterance.onstart = () => {
      startTime = Date.now()
      startTimeRef.current = startTime
    }

    utterance.onend = () => {
      setIsPlaying(false)
      setCurrentTime(0)
    }

    const progressInterval = setInterval(() => {
      if (synth.speaking) {
        const elapsed = (Date.now() - startTimeRef.current) / 1000
        setCurrentTime(Math.min(elapsed, duration))
        window.dispatchEvent(new CustomEvent("audioTimeUpdate", { detail: Math.min(elapsed, duration) }))
      }
    }, 100)

    synthRef.current = utterance
    synth.speak(utterance)

    return () => {
      clearInterval(progressInterval)
      synth.cancel()
    }
  }, [isPlaying, useWebSpeech, voiceScript, duration])

  const handlePlay = () => {
    if (useWebSpeech) {
      setIsPlaying(true)
    } else if (audioRef.current && audioUrl) {
      audioRef.current.play()
      setIsPlaying(true)
    } else {
      // Fallback to Web Speech if no audio
      setUseWebSpeech(true)
      setIsPlaying(true)
    }
  }

  const handlePause = () => {
    if (useWebSpeech) {
      window.speechSynthesis.pause()
    } else if (audioRef.current) {
      audioRef.current.pause()
    }
    setIsPlaying(false)
  }

  const handleStop = () => {
    if (useWebSpeech) {
      window.speechSynthesis.cancel()
    } else if (audioRef.current) {
      audioRef.current.pause()
      audioRef.current.currentTime = 0
    }
    setIsPlaying(false)
    setCurrentTime(0)
  }

  const handleRecord = async () => {
    if (!canvasRef.current) return

    if (isRecording) {
      mediaRecorderRef.current?.stop()
      setIsRecording(false)
    } else {
      recordedChunksRef.current = []
      const stream = canvasRef.current.captureStream(60)

      // Add audio track if available
      if (audioRef.current && !useWebSpeech) {
        try {
          const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)()
          const audioSource = audioContext.createMediaElementAudioSource(audioRef.current)
          const destination = audioContext.createMediaStreamDestination()
          audioSource.connect(destination)

          const audioTrack = destination.stream.getAudioTracks()[0]
          if (audioTrack) {
            stream.addTrack(audioTrack)
          }
        } catch (e) {
          console.warn("Could not add audio track to recording:", e)
        }
      }

      const mediaRecorder = new MediaRecorder(stream, { mimeType: "video/webm" })
      mediaRecorderRef.current = mediaRecorder

      mediaRecorder.ondataavailable = (e) => {
        recordedChunksRef.current.push(e.data)
      }

      mediaRecorder.onstop = () => {
        const blob = new Blob(recordedChunksRef.current, { type: "video/webm" })
        const url = URL.createObjectURL(blob)
        const a = document.createElement("a")
        a.href = url
        a.download = `animation-${Date.now()}.webm`
        a.click()
        URL.revokeObjectURL(url)
      }

      mediaRecorder.start()
      setIsRecording(true)
      handlePlay()
    }
  }

  const downloadAudio = () => {
    if (audioUrl) {
      const a = document.createElement("a")
      a.href = audioUrl
      a.download = `narration-${Date.now()}.mp3`
      a.click()
    }
  }

  const downloadSubtitles = () => {
    if (subtitles) {
      const blob = new Blob([subtitles], { type: "text/plain" })
      const url = URL.createObjectURL(blob)
      const a = document.createElement("a")
      a.href = url
      a.download = `subtitles-${Date.now()}.srt`
      a.click()
      URL.revokeObjectURL(url)
    }
  }

  return (
    <div className="flex flex-col h-full p-4 gap-4">
      {/* Canvas */}
      <div className="flex-1 bg-card rounded-lg border border-border flex items-center justify-center">
        <canvas ref={canvasRef} width={800} height={600} className="max-w-full max-h-full" />
      </div>

      {/* Timeline */}
      <Card className="p-3 space-y-2">
        <div className="flex justify-between text-sm">
          <span>{currentTime.toFixed(1)}s</span>
          <span>{duration.toFixed(1)}s</span>
        </div>
        <input
          type="range"
          min="0"
          max={duration}
          value={currentTime}
          onChange={(e) => {
            const time = Number.parseFloat(e.target.value)
            setCurrentTime(time)
            if (!useWebSpeech && audioRef.current) {
              audioRef.current.currentTime = time
            }
          }}
          className="w-full"
        />
      </Card>

      {/* Playback Controls */}
      <div className="flex gap-2 flex-wrap">
        <Button onClick={handlePlay} disabled={isPlaying} size="sm">
          Play
        </Button>
        <Button onClick={handlePause} disabled={!isPlaying} variant="outline" size="sm">
          Pause
        </Button>
        <Button onClick={handleStop} variant="outline" size="sm">
          Stop
        </Button>
        <Button onClick={handleRecord} variant={isRecording ? "destructive" : "outline"} size="sm">
          {isRecording ? "Stop Recording" : "Record"}
        </Button>
        <div className="ml-auto text-xs text-muted-foreground pt-1">
          {useWebSpeech ? "Web Speech" : audioUrl ? "Audio File" : "No Audio"}
        </div>
      </div>

      {/* Download Buttons */}
      <div className="flex gap-2">
        {audioUrl && (
          <Button onClick={downloadAudio} variant="outline" size="sm" className="text-xs bg-transparent">
            Download Audio
          </Button>
        )}
        {subtitles && (
          <Button onClick={downloadSubtitles} variant="outline" size="sm" className="text-xs bg-transparent">
            Download SRT
          </Button>
        )}
      </div>

      {/* Hidden Audio Element */}
      {audioUrl && !useWebSpeech && <audio ref={audioRef} src={audioUrl} crossOrigin="anonymous" />}
    </div>
  )
}
