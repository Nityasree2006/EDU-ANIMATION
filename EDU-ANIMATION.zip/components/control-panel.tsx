"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { ANIMATION_EXAMPLES } from "@/lib/constants"

interface ControlPanelProps {
  onGenerate: (data: any) => void
  isLoading: boolean
  status: string
}

export default function ControlPanel({ onGenerate, isLoading, status }: ControlPanelProps) {
  const [text, setText] = useState("")
  const [mode, setMode] = useState("simple")
  const [style, setStyle] = useState("minimal")
  const [includeInstructions, setIncludeInstructions] = useState(true)
  const [voiceEnabled, setVoiceEnabled] = useState(true)
  const [voiceProvider, setVoiceProvider] = useState("web-speech")
  const [voiceType, setVoiceType] = useState("narrator")
  const [language, setLanguage] = useState("en")
  const [durationPref, setDurationPref] = useState("medium")

  const handleGenerate = () => {
    if (!text.trim()) return

    onGenerate({
      text,
      mode,
      style,
      includeInstructions,
      voiceEnabled,
      voiceProvider,
      voiceType,
      language,
      durationPreference: durationPref,
    })
  }

  const handleRandomExample = () => {
    const priorities = ANIMATION_EXAMPLES.filter(
      (e) => e.title === "Bernoulli Principle" || e.title === "4×4 Matrix Exponential",
    )
    const options = priorities.length > 0 ? priorities : ANIMATION_EXAMPLES
    const example = options[Math.floor(Math.random() * options.length)]
    setText(example.text)
  }

  const handleReset = () => {
    setText("")
  }

  return (
    <div className="p-4 space-y-4 h-full overflow-y-auto">
      <div>
        <h1 className="text-2xl font-bold">Animation</h1>
        <p className="text-xs text-muted-foreground">Generator</p>
      </div>

      {/* Text Input */}
      <div>
        <label className="block text-sm font-medium mb-2">Describe the animation</label>
        <textarea
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="E.g., Explain Bernoulli's Principle with fluid flow visualization..."
          className="w-full h-24 p-3 border border-border rounded-md bg-card text-foreground resize-none focus:outline-none focus:ring-2 focus:ring-primary text-sm"
          disabled={isLoading}
        />
      </div>

      {/* Mode Selection */}
      <Card className="p-3 space-y-2">
        <label className="block text-sm font-medium">Mode</label>
        <select
          value={mode}
          onChange={(e) => setMode(e.target.value)}
          disabled={isLoading}
          className="w-full p-2 border border-border rounded-md bg-card text-foreground text-sm"
        >
          <option value="simple">Simple</option>
          <option value="advanced">Advanced</option>
        </select>
      </Card>

      {/* Style Selection */}
      <Card className="p-3 space-y-2">
        <label className="block text-sm font-medium">Style</label>
        <select
          value={style}
          onChange={(e) => setStyle(e.target.value)}
          disabled={isLoading}
          className="w-full p-2 border border-border rounded-md bg-card text-foreground text-sm"
        >
          <option value="minimal">Minimal</option>
          <option value="detailed">Detailed</option>
          <option value="cinematic">Cinematic</option>
        </select>
      </Card>

      {/* Duration Preference */}
      <Card className="p-3 space-y-2">
        <label className="block text-sm font-medium">Duration</label>
        <select
          value={durationPref}
          onChange={(e) => setDurationPref(e.target.value)}
          disabled={isLoading}
          className="w-full p-2 border border-border rounded-md bg-card text-foreground text-sm"
        >
          <option value="short">Short (30s)</option>
          <option value="medium">Medium (60s)</option>
          <option value="long">Long (120s)</option>
          <option value="extended">Extended (300s)</option>
        </select>
      </Card>

      {/* Instructions Toggle */}
      <Card className="p-3">
        <label className="flex items-center space-x-2 cursor-pointer">
          <input
            type="checkbox"
            checked={includeInstructions}
            onChange={(e) => setIncludeInstructions(e.target.checked)}
            disabled={isLoading}
            className="cursor-pointer"
          />
          <span className="text-sm font-medium">Include Instructions</span>
        </label>
      </Card>

      {/* Voice Settings */}
      <Card className="p-3 space-y-3">
        <label className="flex items-center space-x-2 cursor-pointer">
          <input
            type="checkbox"
            checked={voiceEnabled}
            onChange={(e) => setVoiceEnabled(e.target.checked)}
            disabled={isLoading}
            className="cursor-pointer"
          />
          <span className="text-sm font-medium">Enable Voice</span>
        </label>

        {voiceEnabled && (
          <>
            <div>
              <label className="block text-xs mb-1 font-medium">Provider</label>
              <select
                value={voiceProvider}
                onChange={(e) => setVoiceProvider(e.target.value)}
                disabled={isLoading}
                className="w-full p-2 border border-border rounded-md bg-card text-foreground text-xs"
              >
                <option value="web-speech">Web Speech</option>
                <option value="elevenlabs">ElevenLabs</option>
                <option value="huggingface">Hugging Face</option>
              </select>
            </div>

            <div>
              <label className="block text-xs mb-1 font-medium">Voice</label>
              <select
                value={voiceType}
                onChange={(e) => setVoiceType(e.target.value)}
                disabled={isLoading}
                className="w-full p-2 border border-border rounded-md bg-card text-foreground text-xs"
              >
                <option value="narrator">Narrator</option>
                <option value="male">Male</option>
                <option value="female">Female</option>
                <option value="robotic">Robotic</option>
              </select>
            </div>

            <div>
              <label className="block text-xs mb-1 font-medium">Language</label>
              <select
                value={language}
                onChange={(e) => setLanguage(e.target.value)}
                disabled={isLoading}
                className="w-full p-2 border border-border rounded-md bg-card text-foreground text-xs"
              >
                <option value="en">English</option>
                <option value="es">Spanish</option>
                <option value="fr">French</option>
                <option value="de">German</option>
              </select>
            </div>
          </>
        )}
      </Card>

      {/* Action Buttons */}
      <div className="space-y-2">
        <Button onClick={handleGenerate} disabled={isLoading || !text.trim()} className="w-full" size="sm">
          {isLoading ? "Generating..." : "Generate"}
        </Button>
        <Button
          onClick={handleRandomExample}
          variant="outline"
          disabled={isLoading}
          className="w-full bg-transparent"
          size="sm"
        >
          Random Example
        </Button>
        <Button
          onClick={handleReset}
          variant="outline"
          disabled={isLoading}
          className="w-full bg-transparent"
          size="sm"
        >
          Reset
        </Button>
      </div>

      {/* Status Messages */}
      {status && (
        <Card className="p-3 bg-muted">
          <p className="text-xs text-muted-foreground animate-pulse">{status}</p>
        </Card>
      )}
    </div>
  )
}
