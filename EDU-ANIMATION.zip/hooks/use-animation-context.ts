"use client"

import { useEffect, useState } from "react"

/**
 * Hook to track current audio/animation time across components
 */
export function useAnimationContext() {
  const [currentTime, setCurrentTime] = useState(0)

  useEffect(() => {
    const handleTimeUpdate = (e: Event) => {
      const customEvent = e as CustomEvent
      setCurrentTime(customEvent.detail)
    }

    window.addEventListener("audioTimeUpdate", handleTimeUpdate)
    return () => window.removeEventListener("audioTimeUpdate", handleTimeUpdate)
  }, [])

  return { currentTime }
}
