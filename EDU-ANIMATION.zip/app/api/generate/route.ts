import { type NextRequest, NextResponse } from "next/server"
import {
  bernoulliScenePlan,
  bernoulliInstructions,
  bernoulliVoiceScript,
  matrixExpmScenePlan,
  matrixExpmInstructions,
  matrixExpmVoiceScript,
  fallbackScenePlan,
  fallbackInstructions,
  fallbackVoiceScript,
} from "@/lib/deterministic-generators"
import { generateSubtitles } from "@/lib/subtitle-generator"
import { generateTTS } from "@/lib/tts-generator"
import type { GenerateRequest, GenerateResponse } from "@/lib/types"

export async function POST(request: NextRequest): Promise<NextResponse<GenerateResponse>> {
  try {
    const body: GenerateRequest = await request.json()
    const {
      text,
      mode = "simple",
      style = "minimal",
      includeInstructions = true,
      voiceEnabled = true,
      voiceProvider = "web-speech",
      voiceType = "narrator",
      language = "en",
      durationPreference = "medium",
    } = body

    if (!text || text.trim().length === 0) {
      return NextResponse.json({ success: false, error: "Text input is required" }, { status: 400 })
    }

    // Determine which deterministic generator to use
    const textLower = text.toLowerCase()
    const isBernoulli = textLower.includes("bernoulli")
    const isMatrix = textLower.includes("4x4") || textLower.includes("matrix exponential")

    let scenes, instructions, voiceScript, voiceScriptDuration

    if (isBernoulli) {
      scenes = bernoulliScenePlan(durationPreference)
      instructions = bernoulliInstructions()
      voiceScript = bernoulliVoiceScript(durationPreference)
    } else if (isMatrix) {
      scenes = matrixExpmScenePlan(durationPreference)
      instructions = matrixExpmInstructions()
      voiceScript = matrixExpmVoiceScript(durationPreference)
    } else {
      // Fallback for other topics
      scenes = fallbackScenePlan(text, durationPreference)
      instructions = fallbackInstructions(text)
      voiceScript = fallbackVoiceScript(text, durationPreference)
    }

    // Estimate voice script duration (words / 150 wpm)
    const wordCount = voiceScript.split(/\s+/).length
    voiceScriptDuration = Math.max(10, Math.ceil((wordCount / 150) * 60)) // seconds

    // Generate TTS if enabled
    let audioUrl = null
    if (voiceEnabled) {
      try {
        const ttsResult = await generateTTS(voiceScript, voiceType, voiceProvider, language)
        audioUrl = ttsResult.audioUrl
        voiceScriptDuration = ttsResult.duration || voiceScriptDuration
      } catch (error) {
        console.warn("TTS generation failed, using fallback duration:", error)
        // Continue with estimated duration
      }
    }

    // Generate subtitles
    const subtitleSrt = generateSubtitles(voiceScript, voiceScriptDuration)

    return NextResponse.json({
      success: true,
      scenes,
      instructions: includeInstructions ? instructions : undefined,
      voiceScript,
      voiceScriptDuration,
      audioUrl,
      subtitleSrt,
    })
  } catch (error) {
    console.error("Generate endpoint error:", error)
    return NextResponse.json({ success: false, error: "Failed to generate animation" }, { status: 500 })
  }
}
