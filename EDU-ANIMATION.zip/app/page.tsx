"use client"

import { useState } from "react"
import ControlPanel from "@/components/control-panel"
import CanvasPanel from "@/components/canvas-panel"
import OutputPanel from "@/components/output-panel"

export default function Home() {
  const [animationData, setAnimationData] = useState(null)
  const [isLoading, setIsLoading] = useState(false)
  const [status, setStatus] = useState("")
  const [audioUrl, setAudioUrl] = useState<string | null>(null)
  const [voiceScript, setVoiceScript] = useState("")
  const [duration, setDuration] = useState(60)
  const [subtitles, setSubtitles] = useState("")

  const handleGenerate = async (formData: any) => {
    setIsLoading(true)
    setStatus("Parsing text...")

    try {
      setStatus("Generating scene breakdown...")
      await new Promise((resolve) => setTimeout(resolve, 300))

      setStatus("Building animation instructions...")
      const response = await fetch("/api/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      })

      const data = await response.json()
      if (data.success) {
        setStatus("Generating voice narration...")
        await new Promise((resolve) => setTimeout(resolve, 200))

        setStatus("Generating subtitles...")
        setAnimationData(data)
        setAudioUrl(data.audioUrl)
        setVoiceScript(data.voiceScript)
        setDuration(data.voiceScriptDuration)
        setSubtitles(data.subtitleSrt)

        setStatus("Rendering preview...")
        await new Promise((resolve) => setTimeout(resolve, 300))

        setStatus("")
      } else {
        setStatus("Error: " + (data.error || "Unknown error"))
      }
    } catch (error) {
      setStatus("Error: Failed to generate animation")
      console.error(error)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <main className="flex h-screen bg-background text-foreground">
      {/* Left Panel */}
      <div className="w-1/4 border-r border-border overflow-y-auto">
        <ControlPanel onGenerate={handleGenerate} isLoading={isLoading} status={status} />
      </div>

      {/* Center Panel */}
      <div className="w-1/2 border-r border-border flex flex-col">
        <CanvasPanel
          animationData={animationData}
          audioUrl={audioUrl}
          duration={duration}
          subtitles={subtitles}
          voiceScript={voiceScript}
        />
      </div>

      {/* Right Panel */}
      <div className="w-1/4 overflow-y-auto">
        <OutputPanel
          animationData={animationData}
          voiceScript={voiceScript}
          subtitles={subtitles}
          duration={duration}
          audioUrl={audioUrl}
        />
      </div>
    </main>
  )
}
