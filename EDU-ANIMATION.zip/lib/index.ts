/**
 * Main library exports for the animation generator
 */

// Types
export type {
  GenerateRequest,
  GenerateResponse,
  SceneItem,
  InstructionSet,
  AnimationStep,
  Keyframe,
  SubtitleEntry,
  TTSResult,
} from "./types"

// Generators
export {
  bernoulliScenePlan,
  bernoulliInstructions,
  bernoulliVoiceScript,
  matrixExpmScenePlan,
  matrixExpmInstructions,
  matrixExpmVoiceScript,
  fallbackScenePlan,
  fallbackInstructions,
  fallbackVoiceScript,
} from "./deterministic-generators"

// Animation Rendering
export {
  renderBernoulliAnimation,
  renderMatrixExpmAnimation,
  renderSineWaveAnimation,
  renderBubbleSortAnimation,
  renderVectorAdditionAnimation,
  renderRotatingTriangleAnimation,
} from "./animation-renderer"

export type { AnimationContext } from "./animation-renderer"

// Subtitle Generation
export {
  generateSubtitles,
  parseSentencesWithTimestamps,
} from "./subtitle-generator"

// TTS
export { generateTTS } from "./tts-generator"

// Test Helpers
export {
  verifyAnimationResponse,
  verifyBernoulliAnimation,
  verifyMatrixExpmAnimation,
  verifySubtitleTiming,
  verifyAnimationDuration,
} from "./test-helpers"

// Utilities
export {
  bernoulliPressureDrop,
  bernoulliLiftForce,
  verifyBernoulliContinuity,
  matrixExpm2x2Approximate,
  matrixExpm4x4Approximate,
  matrixExpmEigenDecomposition,
} from "./deterministic-utils"

// Helpers
export {
  formatTime,
  calculateAnimationDuration,
  easeInOutCubic,
  interpolate,
  generateId,
} from "./helpers"

// Constants
export {
  ANIMATION_EXAMPLES,
  SUPPORTED_LANGUAGES,
  TTS_PROVIDERS,
  VOICE_TYPES,
} from "./constants"
