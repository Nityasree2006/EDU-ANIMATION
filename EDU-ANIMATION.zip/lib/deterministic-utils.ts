/**
 * Utilities for numeric computation in deterministic animations
 */

/**
 * Calculate Bernoulli pressure drop
 * Formula: ΔP = 0.5 * ρ * (v1² - v2²)
 */
export function bernoulliPressureDrop(rho: number, v1: number, v2: number): number {
  return 0.5 * rho * (v1 * v1 - v2 * v2)
}

/**
 * Calculate Bernoulli lift force
 * F_lift = ΔP * A (where A is reference area)
 */
export function bernoulliLiftForce(rho: number, v1: number, v2: number, wingArea: number): number {
  const pressureDrop = bernoulliPressureDrop(rho, v1, v2)
  return pressureDrop * wingArea
}

/**
 * Verify Bernoulli equation continuity
 * p1 + 0.5*ρ*v1² = p2 + 0.5*ρ*v2²
 */
export function verifyBernoulliContinuity(
  p1: number,
  rho: number,
  v1: number,
  p2: number,
  v2: number,
): { valid: boolean; error: number } {
  const side1 = p1 + 0.5 * rho * v1 * v1
  const side2 = p2 + 0.5 * rho * v2 * v2
  const error = Math.abs(side1 - side2)

  return {
    valid: error < 1, // Allow small numerical error
    error,
  }
}

/**
 * Matrix exponential via Taylor series truncation
 * exp(A) = I + A + A²/2! + A³/3! + ... + Aⁿ/n!
 */
export function matrixExpm2x2Approximate(A: number[][], terms = 8): number[][] {
  const size = 2
  let result: number[][] = Array(size)
    .fill(0)
    .map(() => Array(size).fill(0))

  // Start with identity matrix
  for (let i = 0; i < size; i++) {
    result[i][i] = 1
  }

  // Add Taylor series terms
  let Apow: number[][] = identityMatrix(size)
  for (let n = 1; n < terms; n++) {
    Apow = multiplyMatrices(Apow, A)
    const scale = 1 / factorial(n)
    result = addMatrices(result, scaleMatrix(Apow, scale))
  }

  return result
}

/**
 * Matrix exponential for 4×4 via scaling and squaring
 */
export function matrixExpm4x4Approximate(A: number[][], terms = 8): number[][] {
  const size = 4
  const spectralRadius = estimateSpectralRadius(A)

  // Scaling for stability (if needed)
  const scale = Math.max(1, Math.ceil(Math.log2(spectralRadius / 0.5)))
  const scaledA = scaleMatrix(A, 1 / Math.pow(2, scale))

  // Compute exp(A/2^scale)
  let result = taylorSeriesMatrixExpm(scaledA, size, terms)

  // Square scale times to recover exp(A)
  for (let i = 0; i < scale; i++) {
    result = multiplyMatrices(result, result)
  }

  return result
}

/**
 * Eigenvalue-based matrix exponential (for diagonalizable matrices)
 */
export function matrixExpmEigenDecomposition(eigenvalues: number[], eigenvectors: number[][]): number[][] {
  // If we have eigenvalues, exp(A) is easier to compute
  // exp(A) = P * exp(Λ) * P⁻¹
  // where Λ is diagonal matrix of eigenvalues

  const size = eigenvalues.length
  const expLambda: number[][] = Array(size)
    .fill(0)
    .map(() => Array(size).fill(0))

  for (let i = 0; i < size; i++) {
    expLambda[i][i] = Math.exp(eigenvalues[i])
  }

  // In practice, would compute P * exp(Λ) * P⁻¹
  // For now, return the exponential diagonal
  return expLambda
}

// Helper functions

function identityMatrix(size: number): number[][] {
  const I: number[][] = Array(size)
    .fill(0)
    .map(() => Array(size).fill(0))
  for (let i = 0; i < size; i++) {
    I[i][i] = 1
  }
  return I
}

function multiplyMatrices(A: number[][], B: number[][]): number[][] {
  const size = A.length
  const result: number[][] = Array(size)
    .fill(0)
    .map(() => Array(size).fill(0))

  for (let i = 0; i < size; i++) {
    for (let j = 0; j < size; j++) {
      for (let k = 0; k < size; k++) {
        result[i][j] += A[i][k] * B[k][j]
      }
    }
  }

  return result
}

function addMatrices(A: number[][], B: number[][]): number[][] {
  const size = A.length
  const result: number[][] = Array(size)
    .fill(0)
    .map(() => Array(size).fill(0))

  for (let i = 0; i < size; i++) {
    for (let j = 0; j < size; j++) {
      result[i][j] = A[i][j] + B[i][j]
    }
  }

  return result
}

function scaleMatrix(A: number[][], scalar: number): number[][] {
  const size = A.length
  const result: number[][] = Array(size)
    .fill(0)
    .map(() => Array(size).fill(0))

  for (let i = 0; i < size; i++) {
    for (let j = 0; j < size; j++) {
      result[i][j] = A[i][j] * scalar
    }
  }

  return result
}

function factorial(n: number): number {
  if (n <= 1) return 1
  let result = 1
  for (let i = 2; i <= n; i++) {
    result *= i
  }
  return result
}

function estimateSpectralRadius(A: number[][]): number {
  // Simple estimate: max absolute row sum
  const size = A.length
  let maxRowSum = 0

  for (let i = 0; i < size; i++) {
    let rowSum = 0
    for (let j = 0; j < size; j++) {
      rowSum += Math.abs(A[i][j])
    }
    maxRowSum = Math.max(maxRowSum, rowSum)
  }

  return maxRowSum
}

function taylorSeriesMatrixExpm(A: number[][], size: number, terms: number): number[][] {
  let result = identityMatrix(size)
  let Apow = identityMatrix(size)

  for (let n = 1; n < terms; n++) {
    Apow = multiplyMatrices(Apow, A)
    result = addMatrices(result, scaleMatrix(Apow, 1 / factorial(n)))
  }

  return result
}
