/**
 * Test helpers and verification utilities for the animation generator
 */

import type { GenerateResponse } from "./types"

/**
 * Verify that generated animation data is valid
 */
export function verifyAnimationResponse(data: GenerateResponse): { valid: boolean; errors: string[] } {
  const errors: string[] = []

  if (!data.success) {
    errors.push("Response success flag is false")
  }

  if (!data.voiceScript || data.voiceScript.length === 0) {
    errors.push("Voice script is empty")
  }

  if (!data.voiceScriptDuration || data.voiceScriptDuration < 10) {
    errors.push("Voice script duration is invalid or too short")
  }

  if (!data.scenes || data.scenes.length === 0) {
    errors.push("No scenes provided")
  }

  if (!data.subtitleSrt || data.subtitleSrt.length === 0) {
    errors.push("Subtitles are empty")
  }

  // Verify scene structure
  if (data.scenes) {
    data.scenes.forEach((scene, idx) => {
      if (!scene.id) errors.push(`Scene ${idx} missing id`)
      if (!scene.name) errors.push(`Scene ${idx} missing name`)
      if (scene.duration <= 0) errors.push(`Scene ${idx} has invalid duration`)
      if (!scene.animationType) errors.push(`Scene ${idx} missing animationType`)
    })
  }

  return {
    valid: errors.length === 0,
    errors,
  }
}

/**
 * Verify Bernoulli-specific animation data
 */
export function verifyBernoulliAnimation(data: GenerateResponse): { valid: boolean; errors: string[] } {
  const baseErrors = verifyAnimationResponse(data)
  const errors = [...baseErrors.errors]

  if (data.scenes) {
    const hasRelatedScenes = data.scenes.some(
      (s) => s.animationType === "bernoulli" || s.name.toLowerCase().includes("bernoulli"),
    )
    if (!hasRelatedScenes) {
      errors.push("No Bernoulli-related scenes found")
    }

    // Check for continuity in Bernoulli parameters
    data.scenes.forEach((scene) => {
      if (scene.animationType === "bernoulli" && scene.parameters) {
        const { rho, v1, v2, p1 } = scene.parameters
        if (!rho || rho <= 0) errors.push("Invalid density (rho) in Bernoulli scene")
        if (v1 === undefined || v2 === undefined) errors.push("Missing velocities in Bernoulli scene")
        if (!p1 || p1 <= 0) errors.push("Invalid pressure (p1) in Bernoulli scene")
      }
    })
  }

  // Verify voice script mentions key concepts
  const voiceLower = data.voiceScript?.toLowerCase() || ""
  if (!voiceLower.includes("pressure") && !voiceLower.includes("velocity")) {
    errors.push("Voice script does not mention pressure or velocity")
  }

  return {
    valid: errors.length === 0,
    errors,
  }
}

/**
 * Verify Matrix Exponential animation data
 */
export function verifyMatrixExpmAnimation(data: GenerateResponse): { valid: boolean; errors: string[] } {
  const baseErrors = verifyAnimationResponse(data)
  const errors = [...baseErrors.errors]

  if (data.scenes) {
    const hasMatrixScenes = data.scenes.some(
      (s) => s.animationType === "matrix-expm" || s.name.toLowerCase().includes("matrix"),
    )
    if (!hasMatrixScenes) {
      errors.push("No matrix-related scenes found")
    }

    data.scenes.forEach((scene) => {
      if (scene.animationType === "matrix-expm" && scene.parameters?.dimension) {
        if (scene.parameters.dimension !== 4) {
          errors.push("Matrix exponential should use 4×4 matrices")
        }
      }
    })
  }

  // Verify voice script mentions key concepts
  const voiceLower = data.voiceScript?.toLowerCase() || ""
  if (!voiceLower.includes("taylor") && !voiceLower.includes("series") && !voiceLower.includes("exponential")) {
    errors.push("Voice script does not mention Taylor series or exponential")
  }

  return {
    valid: errors.length === 0,
    errors,
  }
}

/**
 * Verify subtitle timing alignment with voice script
 */
export function verifySubtitleTiming(
  subtitleSrt: string,
  voiceScript: string,
  duration: number,
): { valid: boolean; errors: string[]; warnings: string[] } {
  const errors: string[] = []
  const warnings: string[] = []

  // Parse SRT entries
  const entries = parseSRTEntries(subtitleSrt)
  if (entries.length === 0) {
    errors.push("No valid subtitle entries found")
  }

  // Verify entries don't exceed duration
  entries.forEach((entry, idx) => {
    if (entry.endTime > duration) {
      errors.push(`Subtitle ${idx + 1} end time (${entry.endTime}s) exceeds total duration (${duration}s)`)
    }

    if (idx > 0) {
      const prevEntry = entries[idx - 1]
      if (entry.startTime < prevEntry.endTime) {
        warnings.push(`Subtitle ${idx + 1} overlaps with previous entry`)
      } else if (entry.startTime - prevEntry.endTime > 1) {
        warnings.push(
          `Large gap (${(entry.startTime - prevEntry.endTime).toFixed(1)}s) between subtitles ${idx} and ${idx + 1}`,
        )
      }
    }
  })

  // Verify sentence count matches approximate word count
  const sentences = parseSentencesFromScript(voiceScript)
  if (Math.abs(entries.length - sentences.length) > 3) {
    warnings.push(`Subtitle count (${entries.length}) differs from sentence count (${sentences.length})`)
  }

  return {
    valid: errors.length === 0,
    errors,
    warnings,
  }
}

/**
 * Verify animation duration matches content
 */
export function verifyAnimationDuration(
  voiceScript: string,
  claimedDuration: number,
): { valid: boolean; estimatedDuration: number; error?: string } {
  const wordCount = voiceScript.split(/\s+/).length
  const estimatedDuration = Math.ceil((wordCount / 150) * 60) // 150 wpm typical reading speed

  const tolerance = estimatedDuration * 0.2 // Allow 20% variance

  if (Math.abs(claimedDuration - estimatedDuration) > tolerance) {
    return {
      valid: false,
      estimatedDuration,
      error: `Duration mismatch: claimed ${claimedDuration}s, estimated ${estimatedDuration}s based on word count`,
    }
  }

  return {
    valid: true,
    estimatedDuration,
  }
}

// Helper functions

function parseSRTEntries(srt: string): Array<{ index: number; startTime: number; endTime: number; text: string }> {
  const entries: Array<{ index: number; startTime: number; endTime: number; text: string }> = []
  const blocks = srt.split("\n\n").filter((block) => block.trim())

  blocks.forEach((block) => {
    const lines = block.trim().split("\n")
    if (lines.length >= 3) {
      const indexMatch = lines[0].match(/\d+/)
      const timeMatch = lines[1].match(/(\d{2}):(\d{2}):(\d{2}),(\d{3})\s*-->\s*(\d{2}):(\d{2}):(\d{2}),(\d{3})/)

      if (indexMatch && timeMatch) {
        const startTime = timeStringToSeconds(lines[1].split(" --> ")[0])
        const endTime = timeStringToSeconds(lines[1].split(" --> ")[1])
        const text = lines.slice(2).join("\n")

        entries.push({
          index: Number.parseInt(indexMatch[0]),
          startTime,
          endTime,
          text,
        })
      }
    }
  })

  return entries
}

function timeStringToSeconds(timeStr: string): number {
  const match = timeStr.trim().match(/(\d{2}):(\d{2}):(\d{2}),(\d{3})/)
  if (!match) return 0

  const hours = Number.parseInt(match[1])
  const minutes = Number.parseInt(match[2])
  const seconds = Number.parseInt(match[3])
  const ms = Number.parseInt(match[4])

  return hours * 3600 + minutes * 60 + seconds + ms / 1000
}

function parseSentencesFromScript(script: string): string[] {
  return script.match(/[^.!?]+[.!?]+/g) || [script]
}
