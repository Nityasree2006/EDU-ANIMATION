import type { SceneItem } from "./types"

export interface AnimationContext {
  ctx: CanvasRenderingContext2D
  canvas: HTMLCanvasElement
  time: number
  duration: number
  width: number
  height: number
}

export function renderBernoulliAnimation(context: AnimationContext, scene: SceneItem) {
  const { ctx, time, duration, width, height } = context
  const progress = time / duration

  // Clear canvas
  ctx.fillStyle = "#ffffff"
  ctx.fillRect(0, 0, width, height)

  // Draw title
  ctx.fillStyle = "#000000"
  ctx.font = "bold 24px sans-serif"
  ctx.fillText(scene.name, 20, 40)

  // Draw streamlines for air flow
  ctx.strokeStyle = "rgba(0, 100, 200, 0.6)"
  ctx.lineWidth = 2

  const numStreamlines = 8
  for (let i = 0; i < numStreamlines; i++) {
    const y = 100 + (i * 250) / numStreamlines
    ctx.beginPath()
    ctx.moveTo(50, y)

    // Create curved path to show velocity changes
    for (let x = 50; x < width - 50; x += 10) {
      const speedFactor = progress * 0.5 + 0.5 // Ramp up speed
      ctx.lineTo(x, y + Math.sin(x * 0.02 + progress * Math.PI) * 10 * speedFactor)
    }
    ctx.stroke()
  }

  // Draw particle flow
  ctx.fillStyle = "rgba(0, 150, 255, 0.8)"
  for (let i = 0; i < 20; i++) {
    const x = 50 + ((progress * 500 + i * 25) % (width - 100))
    const y = 100 + Math.sin((x + progress * Math.PI * 2) * 0.02) * 50
    ctx.beginPath()
    ctx.arc(x, y, 4, 0, Math.PI * 2)
    ctx.fill()
  }

  // Draw airfoil shape if midway through animation
  if (progress > 0.2) {
    drawAirfoil(ctx, width / 2 - 75, 250, 150, 30)
  }

  // Display pressure values
  ctx.fillStyle = "#333333"
  ctx.font = "14px monospace"
  ctx.fillText(`Time: ${time.toFixed(1)}s`, 20, height - 30)
  ctx.fillText(`Progress: ${(progress * 100).toFixed(0)}%`, 20, height - 10)
}

export function renderMatrixExpmAnimation(context: AnimationContext, scene: SceneItem) {
  const { ctx, time, duration, width, height } = context
  const progress = time / duration

  ctx.fillStyle = "#ffffff"
  ctx.fillRect(0, 0, width, height)

  ctx.fillStyle = "#000000"
  ctx.font = "bold 24px sans-serif"
  ctx.fillText(scene.name, 20, 40)

  // Draw matrix representation
  const matrixSize = 4
  const cellSize = 40
  const startX = 50
  const startY = 100

  // Draw matrix grid
  ctx.strokeStyle = "#000000"
  ctx.lineWidth = 1
  for (let i = 0; i <= matrixSize; i++) {
    // Horizontal lines
    ctx.beginPath()
    ctx.moveTo(startX, startY + i * cellSize)
    ctx.lineTo(startX + matrixSize * cellSize, startY + i * cellSize)
    ctx.stroke()

    // Vertical lines
    ctx.beginPath()
    ctx.moveTo(startX + i * cellSize, startY)
    ctx.lineTo(startX + i * cellSize, startY + matrixSize * cellSize)
    ctx.stroke()
  }

  // Draw and animate matrix values
  ctx.fillStyle = "#000000"
  ctx.font = "12px monospace"
  ctx.textAlign = "center"
  ctx.textBaseline = "middle"

  for (let i = 0; i < matrixSize; i++) {
    for (let j = 0; j < matrixSize; j++) {
      const x = startX + j * cellSize + cellSize / 2
      const y = startY + i * cellSize + cellSize / 2
      // Animate values with easing
      const value = Math.sin(((i + j) * Math.PI) / 4 + progress * Math.PI * 2) * 0.5 + 0.5
      ctx.fillText(value.toFixed(2), x, y)
    }
  }

  // Draw series terms on the right
  ctx.textAlign = "left"
  const seriesY = 100
  const maxTerms = Math.min(Math.floor(progress * 10) + 1, 8)

  ctx.fillStyle = "#666666"
  ctx.font = "12px monospace"
  for (let i = 0; i < maxTerms; i++) {
    ctx.fillText(`+ A^${i}/${i}!`, startX + matrixSize * cellSize + 40, seriesY + i * 25)
  }

  ctx.fillStyle = "#333333"
  ctx.font = "14px monospace"
  ctx.fillText(`Series terms: ${maxTerms}/8`, 20, height - 10)
}

export function renderSineWaveAnimation(context: AnimationContext) {
  const { ctx, time, duration, width, height } = context
  const progress = time / duration

  ctx.fillStyle = "#ffffff"
  ctx.fillRect(0, 0, width, height)

  ctx.strokeStyle = "#0066cc"
  ctx.lineWidth = 3
  ctx.beginPath()

  const centerY = height / 2
  const amplitude = 80
  const frequency = 3

  for (let x = 0; x < width; x += 2) {
    const phase = progress * Math.PI * 2 + (x * frequency * Math.PI) / width
    const y = centerY + Math.sin(phase) * amplitude

    if (x === 0) {
      ctx.moveTo(x, y)
    } else {
      ctx.lineTo(x, y)
    }
  }
  ctx.stroke()

  ctx.fillStyle = "#000000"
  ctx.font = "bold 24px sans-serif"
  ctx.fillText("Sine Wave Animation", 20, 40)
}

export function renderBubbleSortAnimation(context: AnimationContext) {
  const { ctx, time, duration, width, height } = context
  const progress = Math.min(time / duration, 1)

  ctx.fillStyle = "#ffffff"
  ctx.fillRect(0, 0, width, height)

  const n = 10
  const barWidth = (width - 40) / n
  const maxHeight = height - 100

  // Generate deterministic array
  const arr = Array.from({ length: n }, (_, i) => (i + 1) * 0.5 + Math.sin(i) * 0.3)

  // Simple bubble sort visualization
  const currentPass = Math.floor(progress * n)

  ctx.fillStyle = "#000000"
  ctx.font = "bold 24px sans-serif"
  ctx.fillText("Bubble Sort Visualization", 20, 40)

  for (let i = 0; i < n; i++) {
    const barHeight = (arr[i] * maxHeight) / Math.max(...arr)
    const x = 20 + i * barWidth
    const y = height - 20 - barHeight

    ctx.fillStyle = i < currentPass ? "#ff6b6b" : "#4ecdc4"
    ctx.fillRect(x, y, barWidth - 5, barHeight)
  }
}

export function renderVectorAdditionAnimation(context: AnimationContext) {
  const { ctx, time, duration, width, height } = context
  const progress = time / duration

  ctx.fillStyle = "#ffffff"
  ctx.fillRect(0, 0, width, height)

  const centerX = width / 2
  const centerY = height / 2

  // Vector 1
  const v1x = Math.cos(progress * Math.PI * 2) * 100
  const v1y = Math.sin(progress * Math.PI * 2) * 80

  // Vector 2
  const v2x = Math.cos(progress * Math.PI * 2 + Math.PI / 3) * 80
  const v2y = Math.sin(progress * Math.PI * 2 + Math.PI / 3) * 100

  // Draw vector 1
  ctx.strokeStyle = "#ff6b6b"
  ctx.lineWidth = 3
  ctx.beginPath()
  ctx.moveTo(centerX, centerY)
  ctx.lineTo(centerX + v1x, centerY + v1y)
  ctx.stroke()

  // Draw vector 2
  ctx.strokeStyle = "#4ecdc4"
  ctx.beginPath()
  ctx.moveTo(centerX + v1x, centerY + v1y)
  ctx.lineTo(centerX + v1x + v2x, centerY + v1y + v2y)
  ctx.stroke()

  // Draw resultant
  ctx.strokeStyle = "#95e1d3"
  ctx.lineWidth = 2
  ctx.setLineDash([5, 5])
  ctx.beginPath()
  ctx.moveTo(centerX, centerY)
  ctx.lineTo(centerX + v1x + v2x, centerY + v1y + v2y)
  ctx.stroke()
  ctx.setLineDash([])

  ctx.fillStyle = "#000000"
  ctx.font = "bold 24px sans-serif"
  ctx.fillText("Vector Addition", 20, 40)
}

export function renderRotatingTriangleAnimation(context: AnimationContext) {
  const { ctx, time, duration, width, height } = context
  const progress = time / duration

  ctx.fillStyle = "#ffffff"
  ctx.fillRect(0, 0, width, height)

  const centerX = width / 2
  const centerY = height / 2
  const radius = 100
  const rotation = progress * Math.PI * 4

  ctx.save()
  ctx.translate(centerX, centerY)
  ctx.rotate(rotation)

  // Draw triangle
  ctx.fillStyle = "#ff6b6b"
  ctx.beginPath()
  ctx.moveTo(0, -radius)
  ctx.lineTo(radius * Math.cos(Math.PI / 6), radius * Math.sin(Math.PI / 6))
  ctx.lineTo(-radius * Math.cos(Math.PI / 6), radius * Math.sin(Math.PI / 6))
  ctx.closePath()
  ctx.fill()

  ctx.restore()

  ctx.fillStyle = "#000000"
  ctx.font = "bold 24px sans-serif"
  ctx.fillText("Rotating Triangle", 20, 40)
}

function drawAirfoil(ctx: CanvasRenderingContext2D, x: number, y: number, chord: number, height: number) {
  ctx.strokeStyle = "#000000"
  ctx.lineWidth = 2
  ctx.beginPath()

  // Upper surface (NACA-like curve)
  for (let i = 0; i <= chord; i += 5) {
    const t = i / chord
    const yt = height * Math.sin(Math.PI * t) * 0.3
    if (i === 0) {
      ctx.moveTo(x + i, y - yt)
    } else {
      ctx.lineTo(x + i, y - yt)
    }
  }

  // Lower surface
  for (let i = chord; i >= 0; i -= 5) {
    const t = i / chord
    const yt = height * Math.sin(Math.PI * t) * 0.1
    ctx.lineTo(x + i, y + yt)
  }

  ctx.closePath()
  ctx.stroke()
}
