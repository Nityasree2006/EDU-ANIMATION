import type { SceneItem, InstructionSet } from "./types"

// ==================== BERNOULLI'S PRINCIPLE ====================

export function bernoulliScenePlan(durationPreference: string): SceneItem[] {
  const baseDuration = getDurationFromPreference(durationPreference)

  return [
    {
      id: "bernoulli-intro",
      name: "Bernoulli Principle Introduction",
      description: "Animated visualization of Bernoulli's principle with fluid flow",
      duration: baseDuration * 0.3,
      animationType: "bernoulli",
      parameters: { rho: 1.225, v1: 5, v2: 10, p1: 101325 },
    },
    {
      id: "bernoulli-airfoil",
      name: "Airfoil Lift Generation",
      description: "Showing how faster flow over curved surface generates lift",
      duration: baseDuration * 0.4,
      animationType: "bernoulli",
      parameters: { rho: 1.225, v1: 5, v2: 15, p1: 101325 },
    },
    {
      id: "bernoulli-formula",
      name: "Mathematical Formula Application",
      description: "Demonstrating the Bernoulli equation in action",
      duration: baseDuration * 0.3,
      animationType: "bernoulli",
      parameters: { rho: 1.225, v1: 3, v2: 12, p1: 101325 },
    },
  ]
}

export function bernoulliInstructions(): InstructionSet[] {
  return [
    {
      scene: "bernoulli-intro",
      steps: [
        {
          time: 0,
          action: "draw-streamlines",
          parameters: { count: 8, velocity: 5 },
        },
        {
          time: 1,
          action: "animate-particles",
          parameters: { count: 50, speed: 5 },
        },
        {
          time: 2,
          action: "show-pressure",
          parameters: { p1: 101325, p2: 101325 },
        },
      ],
      keyframes: [
        {
          time: 0,
          state: { opacity: 0, scale: 0.8 },
        },
        {
          time: 0.5,
          state: { opacity: 1, scale: 1 },
        },
      ],
    },
    {
      scene: "bernoulli-airfoil",
      steps: [
        {
          time: 0,
          action: "draw-airfoil",
          parameters: { chord: 200, camber: 0.05 },
        },
        {
          time: 0.5,
          action: "increase-velocity",
          parameters: { v1: 5, v2: 15, duration: 2 },
        },
        {
          time: 2.5,
          action: "show-pressure-difference",
          parameters: { deltaP: calculateBernoulliPressure(1.225, 5, 15) },
        },
      ],
      keyframes: [
        {
          time: 0,
          state: { v1: 5, v2: 5, lift: 0 },
        },
        {
          time: 1.5,
          state: { v1: 5, v2: 15, lift: calculateBernoulliLift(1.225, 5, 15) },
        },
      ],
    },
    {
      scene: "bernoulli-formula",
      steps: [
        {
          time: 0,
          action: "show-equation",
          parameters: { equation: "p1 + 0.5*ρ*v1² = p2 + 0.5*ρ*v2²" },
        },
        {
          time: 1,
          action: "highlight-terms",
          parameters: { term: "pressure" },
        },
        {
          time: 2,
          action: "animate-values",
          parameters: { ρ: 1.225, v1: 3, v2: 12 },
        },
      ],
      keyframes: [
        {
          time: 0,
          state: { highlightedTerm: null },
        },
        {
          time: 1,
          state: { highlightedTerm: "p1" },
        },
      ],
    },
  ]
}

export function bernoulliVoiceScript(durationPreference: string): string {
  const base = `Bernoulli's Principle is a fundamental concept in fluid mechanics that describes the relationship between pressure, velocity, and height in a flowing fluid. The principle states that as the velocity of a fluid increases, the pressure within the fluid decreases, assuming the fluid is ideal and incompressible.

This principle has profound real-world applications. Consider an aircraft wing. The curved upper surface is designed so that air flows faster over the top than the bottom. According to Bernoulli's principle, the faster-moving air on top creates a region of lower pressure compared to the higher pressure below, generating an upward force we call lift.

The mathematical expression of Bernoulli's equation is: P1 plus one-half times the density rho times velocity one squared equals P2 plus one-half times density rho times velocity two squared. This relationship holds along a streamline in the flow.

Let's examine the mechanism more carefully. When fluid flows through a narrower section, it must speed up to conserve mass. This increase in velocity directly causes the pressure to decrease. The pressure difference creates the forces that sustain the flow pattern and generate lift on aircraft wings.

Historical context: Daniel Bernoulli discovered this principle in the 18th century through experimental observation of flowing water. His insight revolutionized our understanding of fluid dynamics and laid the groundwork for modern aeronautics.

In practice, engineers use this principle to design everything from aircraft wings to carburetors. The principle is so reliable and fundamental that it remains a cornerstone of fluid mechanics education and engineering design today.`

  if (durationPreference === "extended") {
    return (
      base +
      `\n\nAdvanced Analysis: The derivation of Bernoulli's equation comes from applying conservation of energy to a fluid element. Imagine a small packet of fluid moving through a flow field. The work done by pressure forces plus the work done by gravity must equal the change in kinetic energy of the fluid packet. This energy conservation principle, combined with Newton's laws, yields Bernoulli's equation.

The constant in Bernoulli's equation represents the total mechanical energy per unit volume of the fluid. This constant is only conserved along a streamline, meaning different streamlines can have different values of this constant. This is an important caveat often overlooked in introductory treatments.

Real fluids experience viscosity, which causes energy dissipation. Bernoulli's principle applies most accurately to inviscid flows, though engineering approximations extend its applicability to real-world scenarios. The Reynolds number characterizes the relative importance of inertial and viscous forces.`
    )
  } else if (durationPreference === "long") {
    return (
      base +
      `\n\nFurther Applications: Beyond aviation, Bernoulli's principle explains phenomena in everyday life. Water flowing from a faucet accelerates and becomes narrower as it falls, demonstrating the principle. The Magnus effect, where spinning objects curve through the air, also relies on this principle.`
    )
  }

  return base
}

// ==================== 4×4 MATRIX EXPONENTIAL ====================

export function matrixExpmScenePlan(durationPreference: string): SceneItem[] {
  const baseDuration = getDurationFromPreference(durationPreference)

  return [
    {
      id: "matrix-intro",
      name: "Matrix Exponential Concept",
      description: "Introduction to matrix exponentials and their geometric meaning",
      duration: baseDuration * 0.3,
      animationType: "matrix-expm",
      parameters: { dimension: 4 },
    },
    {
      id: "matrix-series",
      name: "Series Expansion",
      description: "Visual representation of the Taylor series expansion",
      duration: baseDuration * 0.35,
      animationType: "matrix-expm",
      parameters: { dimension: 4, terms: 8 },
    },
    {
      id: "matrix-transform",
      name: "Transformation Visualization",
      description: "How exponential matrix transforms vectors in 4D space",
      duration: baseDuration * 0.35,
      animationType: "matrix-expm",
      parameters: { dimension: 4 },
    },
  ]
}

export function matrixExpmInstructions(): InstructionSet[] {
  return [
    {
      scene: "matrix-intro",
      steps: [
        {
          time: 0,
          action: "show-matrix",
          parameters: {
            matrix: [
              [0, 1, 0, 0],
              [-1, 0, 0, 0],
              [0, 0, 0, 1],
              [0, 0, -1, 0],
            ],
            label: "A",
          },
        },
        {
          time: 1,
          action: "explain-concept",
          parameters: { text: "exp(A) is defined like scalar exponentials" },
        },
      ],
      keyframes: [
        {
          time: 0,
          state: { matrixOpacity: 0 },
        },
        {
          time: 0.5,
          state: { matrixOpacity: 1 },
        },
      ],
    },
    {
      scene: "matrix-series",
      steps: [
        {
          time: 0,
          action: "show-series",
          parameters: {
            terms: ["I", "A", "A²/2!", "A³/3!", "A⁴/4!"],
            maxTerms: 8,
          },
        },
        {
          time: 1,
          action: "animate-convergence",
          parameters: { duration: 3 },
        },
      ],
      keyframes: [
        {
          time: 0,
          state: { termsShown: 1 },
        },
        {
          time: 3,
          state: { termsShown: 8 },
        },
      ],
    },
    {
      scene: "matrix-transform",
      steps: [
        {
          time: 0,
          action: "draw-basis-vectors",
          parameters: { dimension: 4 },
        },
        {
          time: 1,
          action: "apply-transformation",
          parameters: { t: 0, tFinal: 2 },
        },
      ],
      keyframes: [
        {
          time: 0,
          state: { t: 0 },
        },
        {
          time: 2,
          state: { t: 2 },
        },
      ],
    },
  ]
}

export function matrixExpmVoiceScript(durationPreference: string): string {
  const base = `The matrix exponential is a fundamental operation in linear algebra and differential equations. It extends the concept of scalar exponentiation to matrices, enabling us to solve systems of linear differential equations.

For a square matrix A, the matrix exponential exp(A) is defined through its Taylor series expansion. Just as the scalar exponential e to the power x equals the sum from n equals zero to infinity of x to the n over n factorial, the matrix exponential is the sum from n equals zero to infinity of A to the n over n factorial.

This infinite series always converges for any square matrix, making the matrix exponential well-defined. The convergence is surprisingly rapid, especially for small matrices or when the spectral radius is limited.

One crucial property is that exp(A) times the matrix exponential of B equals exp of A plus B only when A and B commute. This non-commutativity reflects the deeper nature of matrix algebra compared to scalar arithmetic.

Matrix exponentials are essential for solving systems of linear differential equations of the form dx over dt equals Ax. The solution is given by x of t equals exp of At times the initial condition x zero. This transforms a difficult differential equation into a pure linear algebra problem.

The connection to eigenvalues and eigenvectors is profound. If A has eigenvalues lambda and corresponding eigenvectors, then exp(A) has eigenvalues exp(lambda). This spectral property allows efficient computation when diagonalization is possible.`

  if (durationPreference === "extended") {
    return (
      base +
      `\n\nComputational Considerations: Calculating the matrix exponential efficiently requires sophisticated numerical methods. The naive truncation of the Taylor series can lead to numerical instability. Modern approaches use scaling and squaring algorithms, which compute exp(A over 2 to the k) to small accuracy, then square the result k times.

Padé approximation provides another powerful method, using rational functions to approximate the exponential. These methods achieve high precision with far fewer terms than naive series truncation.

For special structures, such as skew-symmetric matrices representing rotations, specialized algorithms exploit the geometry. A skew-symmetric matrix represents an infinitesimal rotation, and its exponential is the rotation matrix itself. This connection between matrix exponentials and rotations underlies computer graphics and robotics.

Applications span diverse fields: quantum mechanics uses matrix exponentials for time evolution operators, control theory relies on them for system dynamics, and signal processing employs them in filter design. The fundamental nature of this operation makes it indispensable in modern mathematics and engineering.`
    )
  } else if (durationPreference === "long") {
    return (
      base +
      `\n\nRelated Concepts: The matrix logarithm is the inverse operation, recovering the original matrix from its exponential. Computing the matrix logarithm poses unique challenges, particularly for matrices with negative eigenvalues. Jordan canonical form provides theoretical insight into these computational challenges.`
    )
  }

  return base
}

// ==================== FALLBACK ANIMATIONS ====================

export function fallbackScenePlan(text: string, durationPreference: string): SceneItem[] {
  const baseDuration = getDurationFromPreference(durationPreference)
  const fallbackType = determineFallbackType(text)

  return [
    {
      id: "fallback-1",
      name: "Animation Sequence 1",
      description: `Demonstrating ${fallbackType}`,
      duration: baseDuration * 0.5,
      animationType: fallbackType as any,
      parameters: {},
    },
    {
      id: "fallback-2",
      name: "Animation Sequence 2",
      description: `Continuing ${fallbackType}`,
      duration: baseDuration * 0.5,
      animationType: fallbackType as any,
      parameters: {},
    },
  ]
}

export function fallbackInstructions(text: string): InstructionSet[] {
  return [
    {
      scene: "fallback-1",
      steps: [
        {
          time: 0,
          action: "initialize",
          parameters: {},
        },
      ],
      keyframes: [
        {
          time: 0,
          state: {},
        },
      ],
    },
  ]
}

export function fallbackVoiceScript(text: string, durationPreference: string): string {
  return `This is a demonstration animation generated from your text input. The system has created a visual representation using fundamental animation techniques. This animation illustrates basic principles of motion and transformation. As the animation progresses, observe how the visual elements evolve according to mathematical principles. Each frame builds upon the previous to create a coherent visual narrative.`
}

// ==================== HELPER FUNCTIONS ====================

function getDurationFromPreference(pref: string): number {
  switch (pref) {
    case "short":
      return 30
    case "medium":
      return 60
    case "long":
      return 120
    case "extended":
      return 300
    default:
      return 60
  }
}

function determineFallbackType(text: string): string {
  const lower = text.toLowerCase()
  if (lower.includes("sort")) return "bubble-sort"
  if (lower.includes("sine") || lower.includes("wave")) return "sine-wave"
  if (lower.includes("vector")) return "vector-addition"
  if (lower.includes("rotate") || lower.includes("rotation")) return "rotating-triangle"
  return "sine-wave"
}

function calculateBernoulliPressure(rho: number, v1: number, v2: number): number {
  return 0.5 * rho * (v1 * v1 - v2 * v2)
}

function calculateBernoulliLift(rho: number, v1: number, v2: number): number {
  const pressureDiff = calculateBernoulliPressure(rho, v1, v2)
  return pressureDiff * 200 // Arbitrary wing area for visualization
}
