// Request/Response types for the generate API

export interface GenerateRequest {
  text: string
  mode?: "simple" | "advanced"
  style?: "minimal" | "detailed" | "cinematic"
  includeInstructions?: boolean
  voiceEnabled?: boolean
  voiceProvider?: "server-tts" | "web-speech" | "elevenlabs" | "huggingface"
  voiceType?: "narrator" | "male" | "female" | "robotic"
  language?: string
  durationPreference?: "short" | "medium" | "long" | "extended"
}

export interface SceneItem {
  id: string
  name: string
  description: string
  duration: number // seconds
  animationType: "bernoulli" | "matrix-expm" | "sine-wave" | "bubble-sort" | "vector-addition" | "rotating-triangle"
  parameters?: Record<string, any>
}

export interface InstructionSet {
  scene: string
  steps: AnimationStep[]
  keyframes: Keyframe[]
}

export interface AnimationStep {
  time: number // seconds
  action: string
  parameters?: Record<string, any>
}

export interface Keyframe {
  time: number
  state: Record<string, any>
}

export interface GenerateResponse {
  success: boolean
  error?: string
  scenes?: SceneItem[]
  instructions?: InstructionSet[]
  voiceScript?: string
  voiceScriptDuration?: number
  audioUrl?: string | null
  subtitleSrt?: string
}

export interface SubtitleEntry {
  index: number
  startTime: string
  endTime: string
  text: string
}

export interface TTSResult {
  audioUrl: string
  duration: number
}
