// Example random animations for the "Random Example" button
export const ANIMATION_EXAMPLES = [
  {
    title: "Bernoulli Principle",
    text: "Explain Bernoulli's Principle and how it applies to aircraft wing lift generation. Show the relationship between pressure and velocity in fluid dynamics.",
  },
  {
    title: "4×4 Matrix Exponential",
    text: "Demonstrate the 4x4 matrix exponential through Taylor series expansion, showing convergence and applications in solving differential equations.",
  },
  {
    title: "Sine Wave",
    text: "Visualize a sine wave animation with smooth oscillations and demonstrate harmonic motion principles.",
  },
  {
    title: "Bubble Sort",
    text: "Animate the bubble sort algorithm step by step, showing how elements bubble up to their correct positions.",
  },
  {
    title: "Vector Addition",
    text: "Show how vectors add together using head-to-tail method, demonstrating vector composition.",
  },
  {
    title: "Rotating Triangle",
    text: "Display a rotating triangle that demonstrates rotational motion and angular velocity concepts.",
  },
]

export const FALLBACK_VOICE_SCRIPT = `This is a demonstration animation. The system has generated a visual representation based on your input. Watch as the animation evolves, showing principles of motion and transformation. Each frame builds upon the previous to create a coherent visual narrative that helps explain complex concepts through animation.`

export const SUPPORTED_LANGUAGES = [
  { code: "en", name: "English" },
  { code: "es", name: "Spanish" },
  { code: "fr", name: "French" },
  { code: "de", name: "German" },
  { code: "it", name: "Italian" },
  { code: "pt", name: "Portuguese" },
  { code: "ja", name: "Japanese" },
  { code: "zh", name: "Chinese" },
]

export const TTS_PROVIDERS = [
  { value: "web-speech", label: "Web Speech API (Local)" },
  { value: "elevenlabs", label: "ElevenLabs (API)" },
  { value: "huggingface", label: "Hugging Face (API)" },
]

export const VOICE_TYPES = [
  { value: "narrator", label: "Narrator" },
  { value: "male", label: "Male" },
  { value: "female", label: "Female" },
  { value: "robotic", label: "Robotic" },
]
