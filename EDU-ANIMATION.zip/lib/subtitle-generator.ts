import type { SubtitleEntry } from "./types"

export function generateSubtitles(voiceScript: string, totalDuration: number): string {
  const sentences = splitIntoSentences(voiceScript)
  const entries: SubtitleEntry[] = []

  // Distribute sentences evenly across the total duration
  const durationPerSentence = totalDuration / sentences.length

  sentences.forEach((sentence, index) => {
    const startTime = index * durationPerSentence
    const endTime = (index + 1) * durationPerSentence

    entries.push({
      index: index + 1,
      startTime: formatTimestamp(startTime),
      endTime: formatTimestamp(endTime),
      text: sentence.trim(),
    })
  })

  return formatSRT(entries)
}

function splitIntoSentences(text: string): string[] {
  // Split by sentence-ending punctuation, but handle abbreviations
  const sentences = text.match(/[^.!?]+[.!?]+/g) || [text]
  return sentences.map((s) => s.trim()).filter((s) => s.length > 0)
}

function formatTimestamp(seconds: number): string {
  const hours = Math.floor(seconds / 3600)
  const minutes = Math.floor((seconds % 3600) / 60)
  const secs = Math.floor(seconds % 60)
  const ms = Math.floor((seconds % 1) * 1000)

  return `${String(hours).padStart(2, "0")}:${String(minutes).padStart(2, "0")}:${String(secs).padStart(2, "0")},${String(ms).padStart(3, "0")}`
}

function formatSRT(entries: SubtitleEntry[]): string {
  return entries.map((entry) => `${entry.index}\n${entry.startTime} --> ${entry.endTime}\n${entry.text}`).join("\n\n")
}

export function parseSentencesWithTimestamps(
  voiceScript: string,
  totalDuration: number,
): Array<{ text: string; startTime: number; endTime: number }> {
  const sentences = splitIntoSentences(voiceScript)
  const durationPerSentence = totalDuration / sentences.length

  return sentences.map((sentence, index) => ({
    text: sentence.trim(),
    startTime: index * durationPerSentence,
    endTime: (index + 1) * durationPerSentence,
  }))
}
