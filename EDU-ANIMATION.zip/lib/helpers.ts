/**
 * Utility functions for animation and timing
 */

export function formatTime(seconds: number): string {
  const mins = Math.floor(seconds / 60)
  const secs = Math.floor(seconds % 60)
  return `${mins}:${String(secs).padStart(2, "0")}`
}

export function calculateAnimationDuration(wordCount: number, wordsPerMinute = 150): number {
  // Calculate duration in seconds based on word count
  return Math.ceil((wordCount / wordsPerMinute) * 60)
}

export function easeInOutCubic(t: number): number {
  // Easing function for smooth animation transitions
  return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2
}

export function interpolate(start: number, end: number, progress: number): number {
  // Linear interpolation between two values
  return start + (end - start) * progress
}

export function generateId(prefix: string): string {
  return `${prefix}-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`
}
